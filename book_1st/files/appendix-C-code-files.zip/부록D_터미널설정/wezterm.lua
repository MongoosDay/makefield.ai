-- 내 작업대 설정 (WezTerm) — 『내 문서가 달라졌다』 1-4·1-5
local wezterm = require 'wezterm'
local act = wezterm.action
local config = wezterm.config_builder()

-- ① 글꼴: 한글이 들어간 고정폭 글꼴을 첫째로, 맑은 고딕을 예비로
config.font = wezterm.font_with_fallback {
  'D2Coding',
  'Malgun Gothic',
}
config.font_size = 13.0      -- 글자 크기(포인트). 노트북이면 12, 큰 모니터면 14
config.line_height = 1.2     -- 줄간격. 1.0이 기본, 1.2면 20% 넓게

-- ② 색: 눈이 편한 어두운 배경 + 충분한 대비
config.color_scheme = 'Catppuccin Mocha'

-- ③ 창 크기와 여백
config.initial_cols = 120    -- 가로 글자 수
config.initial_rows = 34     -- 세로 줄 수
config.window_padding = { left = 12, right = 12, top = 8, bottom = 8 }
config.scrollback_lines = 10000   -- 위로 올려 볼 수 있는 줄 수

-- ④ 탭 막대: 아래쪽, 탭이 하나여도 보이게
config.use_fancy_tab_bar = false
config.tab_bar_at_bottom = true
config.hide_tab_bar_if_only_one_tab = false

-- ⑤ 시작 위치와 셸 (1-5)
config.default_prog = { 'powershell.exe', '-NoLogo' }
config.default_cwd = 'C:\\work'

-- ⑥ 단축키 (1-5)
config.keys = {
  -- Ctrl+V: 글자 붙여넣기 (메모장과 같은 손버릇)
  { key = 'v', mods = 'CTRL', action = act.PasteFrom 'Clipboard' },

  -- Alt+Shift+V: 좌우로 나누기 / Alt+Shift+H: 위아래로 나누기
  -- 글자 키에 SHIFT를 섞을 때는 반드시 phys: 를 붙인다 (1-5의 ③)
  { key = 'phys:V', mods = 'ALT|SHIFT', action = act.SplitHorizontal { cwd = 'C:\\work' } },
  { key = 'phys:H', mods = 'ALT|SHIFT', action = act.SplitVertical { cwd = 'C:\\work' } },

  -- Alt+화살표: 나눈 칸 사이 이동
  { key = 'LeftArrow',  mods = 'ALT', action = act.ActivatePaneDirection 'Left' },
  { key = 'RightArrow', mods = 'ALT', action = act.ActivatePaneDirection 'Right' },
  { key = 'UpArrow',    mods = 'ALT', action = act.ActivatePaneDirection 'Up' },
  { key = 'DownArrow',  mods = 'ALT', action = act.ActivatePaneDirection 'Down' },

  -- Alt+W: 지금 칸 닫기 (닫기 전에 한 번 묻는다)
  { key = 'w', mods = 'ALT', action = act.CloseCurrentPane { confirm = true } },

  -- Ctrl+Shift+1~3: 자주 가는 폴더를 새 탭으로
  { key = 'phys:1', mods = 'CTRL|SHIFT', action = act.SpawnCommandInNewTab { cwd = 'C:\\work' } },
  { key = 'phys:2', mods = 'CTRL|SHIFT', action = act.SpawnCommandInNewTab { cwd = 'C:\\work\\report' } },
  { key = 'phys:3', mods = 'CTRL|SHIFT', action = act.SpawnCommandInNewTab { cwd = 'C:\\work\\data' } },
}

return config
