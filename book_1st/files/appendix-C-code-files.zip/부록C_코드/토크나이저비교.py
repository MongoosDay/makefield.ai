# [부록 C] 『내 문서가 달라졌다』 6-2·6-3 — 저자 PC에서 2026-09-28 실행 확인 (Python 3.12, SQLite 3.49, CPU)
import sqlite3, pathlib
ROOT = pathlib.Path("샘플폴더")
docs = [(p.name, p.read_text(encoding="utf-8")) for p in sorted(ROOT.iterdir()) if p.suffix in (".md",".txt")]
con = sqlite3.connect(":memory:")
for tok in ["unicode61", "trigram"]:
    con.execute(f"CREATE VIRTUAL TABLE t_{tok} USING fts5(name, body, tokenize='{tok}')")
    con.executemany(f"INSERT INTO t_{tok} VALUES (?,?)", docs)
def n_match(tok, q):
    try: return len(con.execute(f"SELECT name FROM t_{tok} WHERE t_{tok} MATCH ?", (q,)).fetchall())
    except Exception as e: return f"오류:{e}"
def n_like(tok, w):
    return len(con.execute(f"SELECT name FROM t_{tok} WHERE body LIKE ?", (f"%{w}%",)).fetchall())
import re
for w in ["견적서", "납기", "계약", "단가", "재계약", "KX-2041", "늦어져서", "늦어"]:
    truth = sum(1 for _, b in docs if w in b)
    print(f"{w!r:12} 실제포함={truth:3}  unicode61={n_match('unicode61', chr(34)+w+chr(34))!s:>4}  trigram={n_match('trigram', chr(34)+w+chr(34))!s:>4}  trigram-LIKE={n_like('trigram', w)}")
