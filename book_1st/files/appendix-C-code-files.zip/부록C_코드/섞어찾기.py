# [부록 C] 『내 문서가 달라졌다』 6-5 — 저자 PC에서 2026-09-28 실행 확인 (Python 3.12, SQLite 3.49, CPU)
# 섞어찾기.py — 키워드 검색과 의미 검색의 순위를 섞는다 (RRF: 순위 역수 합산)
# 먼저 두 색인을 만들어 둔다:
#   python 키워드검색.py 색인 "C:\공유폴더\영업"
#   python 의미검색.py 색인 "C:\공유폴더\영업"
# 사용:  python 섞어찾기.py 납기 지연
import sys, io, contextlib, pathlib
import 키워드검색, 의미검색

K = 60      # 순위 점수를 완만하게 만드는 상수. 원 논문(Cormack 외, 2009)이 쓴 값
위쪽 = 10   # 각 검색에서 위쪽 10개만 섞는다 (아래쪽 잡음이 끼어들지 않게)

def 섞어찾기(질문, 몇개=5, 출력=True):
    with contextlib.redirect_stdout(io.StringIO()):          # 각자 출력은 숨긴다
        키워드 = 키워드검색.찾기(질문.split(), 몇개=0)[:위쪽]
    의미 = 의미검색.찾기(질문, 출력=False)[:위쪽]
    점수, 출신 = {}, {}
    for 이름, 목록 in [("키워드", 키워드), ("의미", 의미)]:
        for 순위, 경로 in enumerate(목록, 1):
            점수[경로] = 점수.get(경로, 0) + 1 / (K + 순위)   # 1등 1/61, 2등 1/62 …
            출신.setdefault(경로, []).append(f"{이름} {순위}등")
    결과 = sorted(점수, key=lambda p: -점수[p])
    if 출력:
        for 경로 in 결과[:몇개]:
            print(f"{pathlib.Path(경로).name}   ← " + ", ".join(출신[경로]))
        if not 결과:
            print("두 방식 모두 못 찾음 — 6-5의 진단 4단계로")
    return 결과

if __name__ == "__main__":
    섞어찾기(" ".join(sys.argv[1:]))
