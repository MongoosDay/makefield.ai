$dir = "C:\ai\morning"
$today = Get-Date -Format "yyyy-MM-dd"
$flag = Get-Item "$dir\start.flag" -ErrorAction SilentlyContinue   # run.bat이 실행 시작 때 만드는 표시(8-2)
$out = if ($flag) { Get-ChildItem $dir -Filter "*$today*.md" | Where-Object { $_.LastWriteTime -gt $flag.LastWriteTime } | Select-Object -First 1 }
$src = (Get-ChildItem "$dir\inbox" -File).Count
$done = if ($out) { (Select-String -Path $out.FullName -Pattern '^- ').Count } else { 0 }
$err = (Select-String -Path "$dir\run.log" -Pattern 'error|fail|실패' -Encoding utf8).Count
"1. 오늘 결과물: " + $(if ($out) { $out.Name } else { '없음 <- 실패' })
"2. 건수: 원본 $src / 결과 $done " + $(if ($src -ne $done) { '<- 불일치' } else { '' })
"3. 로그 속 에러 줄: $err " + $(if ($err -gt 0) { '<- 확인' } else { '' })
