# [부록 C] 『내 문서가 달라졌다』 6-4 — 저자 PC에서 2026-09-28 실행 확인 (Python 3.12, SQLite 3.49, CPU)
# 의미검색.py — 문단을 '뜻의 좌표'(임베딩)로 바꿔 두고, 질문과 뜻이 가까운 문서를 찾는다
# 준비(한 번만):  pip install sentence-transformers
# 사용:  python 의미검색.py 색인 "C:\공유폴더\영업"
#        python 의미검색.py 찾기 배송이 늦어진 건
import sys, json, pathlib
import numpy as np
from sentence_transformers import SentenceTransformer

모델이름 = "paraphrase-multilingual-MiniLM-L12-v2"   # 한국어 포함 다국어, 내 PC(CPU)에서 돈다
여기 = pathlib.Path(__file__).parent
좌표파일, 목록파일 = 여기 / "의미색인.npy", 여기 / "의미색인.json"
읽을확장자 = {".md", ".txt"}
_모델 = None

def 모델():
    global _모델
    if _모델 is None:
        _모델 = SentenceTransformer(모델이름, device="cpu")   # 첫 실행 때 한 번 내려받음
    return _모델

def 색인(폴더):
    조각들, 출처 = [], []
    for p in sorted(pathlib.Path(폴더).rglob("*")):
        if not p.is_file() or p.suffix.lower() not in 읽을확장자:
            continue
        본문 = p.read_text(encoding="utf-8", errors="ignore")
        제목 = 본문.strip().split("\n")[0].lstrip("# ")
        # 문단(빈 줄) 단위로 자른다 — 이 모델은 한 번에 짧은 글만 읽기 때문
        # 제목만 있는 줄은 빼고, 각 문단 앞에 문서 제목을 붙여 둔다
        for 문단 in [x.strip() for x in 본문.split("\n\n") if x.strip()]:
            if 문단.startswith("#"):
                continue
            조각들.append(제목 + " — " + 문단)
            출처.append(str(p))
    좌표 = 모델().encode(조각들, normalize_embeddings=True, show_progress_bar=True)
    np.save(좌표파일, 좌표.astype(np.float32))
    json.dump({"출처": 출처, "조각": 조각들}, open(목록파일, "w", encoding="utf-8"), ensure_ascii=False)
    print(f"색인 완료: 문서 {len(set(출처))}개, 문단 {len(조각들)}개")

def 찾기(질문, 몇개=5, 출력=True):
    좌표 = np.load(좌표파일)
    목록 = json.load(open(목록파일, encoding="utf-8"))
    q = 모델().encode([질문], normalize_embeddings=True)[0]
    점수 = 좌표 @ q                          # 뜻이 얼마나 가까운가 (1에 가까울수록 비슷)
    문서점수 = {}
    for i, s in enumerate(점수):           # 한 문서에서 가장 가까운 문단의 점수를 문서 점수로
        경로 = 목록["출처"][i]
        if s > 문서점수.get(경로, (-1, 0))[0]:
            문서점수[경로] = (float(s), i)
    순위 = sorted(문서점수.items(), key=lambda x: -x[1][0])
    if 출력:
        for 경로, (s, i) in 순위[:몇개]:
            print(f"[{s:.2f}] {pathlib.Path(경로).name}")
            print("    …" + 목록["조각"][i][:60].replace("\n", " ") + "…")
    return [경로 for 경로, _ in 순위]

if __name__ == "__main__":
    if sys.argv[1] == "색인":
        색인(sys.argv[2])
    else:
        찾기(" ".join(sys.argv[2:]))
