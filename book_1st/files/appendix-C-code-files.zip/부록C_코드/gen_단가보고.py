# gen_단가보고.py — 월간 단가 변동 보고서를 다시 만드는 절차
# 사용법: python gen_단가보고.py 2026-10
#   → 같은 폴더의 '단가_2026-10.xlsx'를 읽어 '단가보고_2026-10.docx'를 만든다
import os
import sys
import openpyxl
from docx import Document
from docx.shared import Pt
from docx.oxml.ns import qn

# ── 1. 이번 달 설정 (매달 바뀌는 건 이것뿐) ──────────────
MONTH = sys.argv[1] if len(sys.argv) > 1 else "2026-09"
SRC = f"단가_{MONTH}.xlsx"
OUT = f"단가보고_{MONTH}.docx"
FONT = "맑은 고딕"
if not os.path.exists(SRC):
    sys.exit(f"[중단] 원본 파일이 없습니다: {SRC}")

# ── 2. 원본 읽기 (엑셀 첫 줄은 제목 줄) ───────────────────
ws = openpyxl.load_workbook(SRC, data_only=True).active
rows = [r for r in ws.iter_rows(min_row=2, values_only=True) if r[0]]

# ── 3. 계산 ──────────────────────────────────────────────
items = []
for name, vendor, old, new, qty in rows:
    items.append((name, vendor, old, new, (new - old) * qty))
total = sum(i[4] for i in items)
up = [i for i in items if i[4] > 0]

# ── 4. 문서 만들기 ───────────────────────────────────────
doc = Document()
st = doc.styles["Normal"]
st.font.name, st.font.size = FONT, Pt(10)
st.element.rPr.rFonts.set(qn("w:eastAsia"), FONT)

doc.add_heading(f"{MONTH} 거래처 단가 변동 보고", level=1)
doc.add_paragraph(
    f"결론: 이번 달 단가 변동으로 월 비용이 {abs(total):,}원 "
    f"{'늘어납니다' if total > 0 else '줄어듭니다'}. "
    f"인상 품목 {len(up)}건 중 영향이 가장 큰 것은 "
    f"'{max(items, key=lambda i: i[4])[0]}'입니다.")

t = doc.add_table(rows=1, cols=5)
t.style = "Table Grid"
for c, h in zip(t.rows[0].cells, ["품목", "거래처", "이전 단가", "신규 단가", "월 영향(원)"]):
    c.text = h
for name, vendor, old, new, diff in items:
    cells = t.add_row().cells
    for c, v in zip(cells, [name, vendor, f"{old:,}", f"{new:,}", f"{diff:+,}"]):
        c.text = v

doc.save(OUT)
print(f"[생성 완료] {OUT}  (품목 {len(rows)}건, 합계 {total:+,}원)")

# ── 5. 검사: 한 달에 30% 넘게 바뀐 단가는 입력 실수일 수 있다 ──
for name, vendor, old, new, diff in items:
    if abs(new - old) > old * 0.3:
        print(f"[확인필요] {name}: {old:,}원 → {new:,}원 (30% 넘게 변동)")
