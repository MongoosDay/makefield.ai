# [부록 C] 『내 문서가 달라졌다』 6-2 — 저자 PC에서 2026-09-28 실행 확인 (Python 3.12, SQLite 3.49, CPU)
# 키워드검색.py — 폴더의 .md/.txt 를 색인하고 단어로 찾는다 (파이썬 기본 기능만 사용)
# 사용:  python 키워드검색.py 색인 "C:\공유폴더\영업"
#        python 키워드검색.py 찾기 납기 지연
import sqlite3, sys, pathlib

DB = pathlib.Path(__file__).with_name("검색색인.db")   # 색인 파일(=찾아보기 목록)
읽을확장자 = {".md", ".txt"}

def 색인(폴더):
    con = sqlite3.connect(DB)
    con.execute("DROP TABLE IF EXISTS 문서")
    # trigram: 글자를 3개씩 겹쳐 잘라 둔다 → '견적서를' 안의 '견적서'도 찾힌다
    con.execute("CREATE VIRTUAL TABLE 문서 USING fts5(경로, 본문, tokenize='trigram')")
    넣음, 건너뜀 = 0, {}
    for p in pathlib.Path(폴더).rglob("*"):
        if not p.is_file():
            continue
        if p.suffix.lower() not in 읽을확장자:
            건너뜀[p.suffix.lower()] = 건너뜀.get(p.suffix.lower(), 0) + 1
            continue
        본문 = p.read_text(encoding="utf-8", errors="ignore")
        con.execute("INSERT INTO 문서 VALUES (?, ?)", (str(p), 본문))
        넣음 += 1
    con.commit()
    print(f"색인 완료: {넣음}개")
    for 확장자, 개수 in 건너뜀.items():
        print(f"  건너뜀 {확장자 or '(확장자 없음)'}: {개수}개")   # ← 못 찾을 때 제일 먼저 볼 곳

def 찾기(단어들, 몇개=5):
    con = sqlite3.connect(DB)
    # 두 글자 단어는 trigram 검색(MATCH)에 안 걸리므로 LIKE 로 찾는다
    조건 = " OR ".join("본문 LIKE ?" for _ in 단어들)
    행들 = con.execute(f"SELECT 경로, 본문 FROM 문서 WHERE {조건}",
                      [f"%{w}%" for w in 단어들]).fetchall()
    결과 = []
    for 경로, 본문 in 행들:
        맞은단어 = sum(1 for w in 단어들 if w in 본문)      # 검색어가 몇 종류나 들어 있나
        횟수 = sum(본문.count(w) for w in 단어들)          # 몇 번 나오나
        결과.append((맞은단어, 횟수, 경로, 본문))
    결과.sort(reverse=True)
    for 맞은단어, 횟수, 경로, 본문 in 결과[:몇개]:
        i = 본문.find(next(w for w in 단어들 if w in 본문))
        print(f"[{맞은단어}종류/{횟수}회] {pathlib.Path(경로).name}")
        print("    …" + 본문[max(0, i - 20):i + 40].replace("\n", " ") + "…")
    if not 결과:
        print("찾은 문서 없음 — '없다'가 아니라 '이 단어로는 못 찾았다'입니다")
    return [r[2] for r in 결과]

if __name__ == "__main__":
    if sys.argv[1] == "색인":
        색인(sys.argv[2])
    else:
        찾기(sys.argv[2:])
