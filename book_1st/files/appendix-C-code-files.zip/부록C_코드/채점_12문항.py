# [부록 C] 『내 문서가 달라졌다』 6-5 — 저자 PC에서 2026-09-28 실행 확인 (Python 3.12, SQLite 3.49, CPU)
# 채점.py — 정답을 아는 질문 12개로 세 방식(키워드/의미/섞기)을 채점한다
import sys, io, contextlib, pathlib, importlib
모듈명 = sys.argv[1] if len(sys.argv) > 1 else "의미검색"
sys.argv = ["x"]
import 키워드검색 as K

시험 = [  # (질문, 정답 파일)
    ("납기 지연", "회의록_2025-11-03.md"),
    ("포장 불량", "클레임_2025-09-12.md"),
    ("단가 인상", "통화메모_2025-10-02.md"),
    ("대금 미지급", "업무일지_2025-08-21.md"),
    ("야근 수당", "인사메모_2025-06-30.md"),
    ("재고 부족", "창고현황_2025-10-20.md"),
    ("출장 경비 정산", "출장보고_2025-07-15.md"),
    ("KX-2041", "부품목록_2025.md"),
    ("A상사 재계약", "계약메모_2025-12-01.md"),
    ("품질 검사 기준", "품질기준_v2.md"),
    ("3월 월간 보고", "월보고_2025-03.md"),
    ("신입 안내", "교육자료_신입.md"),
]

def 섞기(목록들, k=60):
    점수 = {}
    for 목록 in 목록들:
        for 순위, 경로 in enumerate(목록, 1):
            점수[경로] = 점수.get(경로, 0) + 1 / (k + 순위)
    return [p for p, _ in sorted(점수.items(), key=lambda x: -x[1])]

def 등수(목록, 정답):
    names = [pathlib.Path(p).name for p in 목록]
    return names.index(정답) + 1 if 정답 in names else None

M = importlib.import_module(모듈명)
import 섞어찾기 as H
행 = []
for 질문, 정답 in 시험:
    with contextlib.redirect_stdout(io.StringIO()):
        kw = K.찾기(질문.split(), 몇개=0)
    sem = M.찾기(질문, 출력=False)
    hy = H.섞어찾기(질문, 출력=False)
    행.append((질문, 등수(kw, 정답), 등수(sem, 정답), 등수(hy, 정답)))
def 표(x): return "-" if x is None else str(x)
print("질문 | 키워드 | 의미 | 섞기   (정답 문서 등수, -는 못 찾음)")
for q, a, b, c in 행:
    print(f"{q} | {표(a)} | {표(b)} | {표(c)}")
for 이름, j in [("키워드", 1), ("의미", 2), ("섞기", 3)]:
    top1 = sum(1 for r in 행 if r[j] == 1)
    top5 = sum(1 for r in 행 if r[j] is not None and r[j] <= 5)
    print(f"{이름}: 1등 {top1}/12, 5등 안 {top5}/12")
