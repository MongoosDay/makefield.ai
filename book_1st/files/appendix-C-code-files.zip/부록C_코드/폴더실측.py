# [부록 C] 『내 문서가 달라졌다』 6-1 — 저자 PC에서 2026-09-28 실행 확인 (Python 3.12, SQLite 3.49, CPU)
# 폴더실측.py — 폴더 안 글이 모두 몇 자인지, AI 한 번에 다 들어가는지 잰다
# 사용:  python 폴더실측.py "C:\공유폴더\영업"
import sys, pathlib

폴더 = pathlib.Path(sys.argv[1])
읽을확장자 = {".md", ".txt"}
글자수, 파일수, 못읽음 = 0, 0, {}
가장큰 = []
for p in 폴더.rglob("*"):
    if not p.is_file():
        continue
    if p.suffix.lower() in 읽을확장자:
        n = len(p.read_text(encoding="utf-8", errors="ignore"))
        글자수 += n
        파일수 += 1
        가장큰.append((n, p.name))
    else:
        못읽음[p.suffix.lower()] = 못읽음.get(p.suffix.lower(), 0) + 1

print(f"글 파일 {파일수}개, 합계 {글자수:,}자")
for n, 이름 in sorted(가장큰, reverse=True)[:3]:
    print(f"  가장 긴 파일: {이름} ({n:,}자)")
for 확장자, 개수 in 못읽음.items():
    print(f"  이 방법으로는 못 읽은 파일 {확장자}: {개수}개")

try:  # 토큰 수(AI가 글을 세는 단위). tiktoken 이 있으면 센다: pip install tiktoken
    import tiktoken
    enc = tiktoken.get_encoding("o200k_base")
    토큰 = sum(len(enc.encode(p.read_text(encoding="utf-8", errors="ignore")))
             for p in 폴더.rglob("*") if p.is_file() and p.suffix.lower() in 읽을확장자)
    print(f"토큰 약 {토큰:,}개  (글자 1자당 약 {토큰 / max(글자수, 1):.2f}토큰)")
except ImportError:
    print("토큰 수는 건너뜀 (pip install tiktoken 후 다시 실행)")
